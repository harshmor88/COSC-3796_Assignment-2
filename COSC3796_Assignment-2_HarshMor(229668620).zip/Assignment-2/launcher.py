# launcher.py
import subprocess
import sys
import time
import os
import webbrowser

def start_server():
    """Start the Flask server"""
    print("[*] Starting Flask server...")
    server_process = subprocess.Popen(
        [sys.executable, "server.py"],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True
    )
    
    # Give server time to start
    time.sleep(3)
    return server_process

def start_game():
    """Start the Mario game"""
    print("[*] Starting Mario game...")
    game_process = subprocess.Popen(
        [sys.executable, "run_game.py"],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True
    )
    return game_process

def open_browser():
    """Open browser to the server"""
    time.sleep(2)  # Wait for server to be ready
    webbrowser.open("http://localhost:5000")

if __name__ == "__main__":
    print("=" * 50)
    print("🎮 Mario Game + Screenshot Monitor Launcher")
    print("=" * 50)
    
    print("\n1. Starting Flask screenshot server...")
    server = start_server()
    
    print("2. Opening browser to monitor...")
    open_browser()
    
    print("\n3. Starting Mario game...")
    print("   (Press Ctrl+C in this window to stop everything)")
    print("-" * 50)
    
    try:
        # Start the game
        game = start_game()
        
        # Keep launcher running
        while True:
            time.sleep(1)
            
    except KeyboardInterrupt:
        print("\n\n[*] Shutting down...")
        print("[*] Terminating processes...")
        
        # Terminate processes
        server.terminate()
        game.terminate()
        
        print("[*] All processes terminated. Goodbye!")