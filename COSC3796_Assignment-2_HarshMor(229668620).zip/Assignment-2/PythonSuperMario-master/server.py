# server.py - PUT THIS IN PythonSuperMario-master FOLDER
from flask import Flask, request, jsonify, send_file
import os
import tempfile
import atexit
import shutil

print("=" * 60)
print("🎮 MARIO SCREENSHOT SERVER")
print("=" * 60)

# ALWAYS use temp directory - it NEVER has permission issues
TEMP_DIR = tempfile.gettempdir()
UPLOAD_FOLDER = os.path.join(TEMP_DIR, 'MarioGameScreenshots')

print(f"✅ Using TEMP directory (always writable):")
print(f"   {UPLOAD_FOLDER}")

# Clean old files on exit
def cleanup():
    if os.path.exists(UPLOAD_FOLDER):
        try:
            shutil.rmtree(UPLOAD_FOLDER)
            print("🧹 Cleaned up temp files")
        except:
            pass

atexit.register(cleanup)

# Create folder
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
print(f"📁 Created folder successfully")
print(f"✅ Write permission: {os.access(UPLOAD_FOLDER, os.W_OK)}")

app = Flask(__name__)

@app.route('/upload', methods=['POST'])
def upload_file():
    print("\n📨 Received screenshot upload request")
    
    if 'file' not in request.files:
        print("❌ No file in request")
        return jsonify({"error": "No file part"}), 400
    
    file = request.files['file']
    if file.filename == '':
        print("❌ Empty filename")
        return jsonify({"error": "No selected file"}), 400
    
    try:
        # Create simple filename
        import time
        filename = f"mario_{int(time.time())}.png"
        filepath = os.path.join(UPLOAD_FOLDER, filename)
        
        print(f"💾 Saving to: {filepath}")
        file.save(filepath)
        
        file_size = os.path.getsize(filepath)
        print(f"✅ Saved! Size: {file_size:,} bytes")
        
        return jsonify({
            "success": True,
            "message": f"Screenshot saved ({file_size:,} bytes)",
            "filename": filename,
            "path": filepath
        })
        
    except Exception as e:
        print(f"❌ Error saving: {e}")
        return jsonify({"error": str(e)}), 500

@app.route('/')
def index():
    """Show latest screenshot or welcome page"""
    import glob
    
    # Find all PNG files
    screenshots = glob.glob(os.path.join(UPLOAD_FOLDER, "*.png"))
    
    if screenshots:
        # Get most recent
        latest = max(screenshots, key=os.path.getctime)
        print(f"🖼️ Serving latest screenshot: {os.path.basename(latest)}")
        return send_file(latest, mimetype='image/png')
    else:
        # Show welcome page
        return """
        <!DOCTYPE html>
        <html>
        <head>
            <title>🎮 Mario Screenshot Monitor</title>
            <style>
                body {
                    font-family: Arial, sans-serif;
                    text-align: center;
                    padding: 50px;
                    background: #1a1a2e;
                    color: white;
                }
                .container {
                    max-width: 600px;
                    margin: 0 auto;
                    background: rgba(255,255,255,0.1);
                    padding: 30px;
                    border-radius: 10px;
                }
                h1 { color: #4dff91; }
                .status {
                    background: rgba(0,0,0,0.3);
                    padding: 20px;
                    border-radius: 5px;
                    margin: 20px 0;
                }
                code {
                    background: black;
                    padding: 10px;
                    display: block;
                    margin: 10px 0;
                    border-radius: 5px;
                }
            </style>
        </head>
        <body>
            <div class="container">
                <h1>🍄 Super Mario Screenshot Monitor 🍄</h1>
                <p>Server is running and ready!</p>
                
                <div class="status">
                    <h3>⚡ Status: WAITING FOR SCREENSHOTS</h3>
                    <p>Start the Mario game to begin capturing screenshots</p>
                    <p>Screenshots will appear here automatically</p>
                </div>
                
                <div style="text-align: left;">
                    <h4>📋 Server Info:</h4>
                    <p><strong>Upload Folder:</strong> <code>""" + UPLOAD_FOLDER + """</code></p>
                    <p><strong>Upload Endpoint:</strong> <code>POST /upload</code></p>
                    <p><strong>Game Running:</strong> """ + ("✅ Yes" if len(screenshots) > 0 else "❌ No") + """</p>
                </div>
                
                <button onclick="location.reload()" style="
                    background: #4dff91;
                    color: black;
                    border: none;
                    padding: 10px 20px;
                    font-size: 16px;
                    border-radius: 5px;
                    cursor: pointer;
                    margin-top: 20px;
                ">
                    🔄 Refresh Page
                </button>
            </div>
            
            <script>
                // Auto-refresh every 5 seconds
                setTimeout(() => location.reload(), 5000);
            </script>
        </body>
        </html>
        """

@app.route('/list')
def list_screenshots():
    """List all screenshots"""
    import glob
    from datetime import datetime
    
    screenshots = []
    for filepath in glob.glob(os.path.join(UPLOAD_FOLDER, "*.png")):
        name = os.path.basename(filepath)
        size = os.path.getsize(filepath)
        modified = datetime.fromtimestamp(os.path.getmtime(filepath))
        screenshots.append({
            'name': name,
            'size': f"{size:,} bytes",
            'modified': modified.strftime("%Y-%m-%d %H:%M:%S"),
            'url': f'/view/{name}'
        })
    
    # Sort by newest first
    screenshots.sort(key=lambda x: x['modified'], reverse=True)
    
    html = "<h1>📁 All Mario Screenshots</h1>"
    html += f"<p>Total: {len(screenshots)}</p>"
    html += "<table border='1' style='width:100%'>"
    html += "<tr><th>Filename</th><th>Size</th><th>Captured</th><th>View</th></tr>"
    
    for shot in screenshots:
        html += f"""
        <tr>
            <td>{shot['name']}</td>
            <td>{shot['size']}</td>
            <td>{shot['modified']}</td>
            <td><a href="{shot['url']}">View</a></td>
        </tr>
        """
    
    html += "</table>"
    html += "<br><a href='/'>← Back to Home</a>"
    return html

@app.route('/view/<filename>')
def view_screenshot(filename):
    """View specific screenshot"""
    filepath = os.path.join(UPLOAD_FOLDER, filename)
    if os.path.exists(filepath):
        return send_file(filepath, mimetype='image/png')
    return "File not found", 404

@app.route('/test')
def test_page():
    """Test if server is working"""
    return jsonify({
        "status": "running",
        "upload_folder": UPLOAD_FOLDER,
        "folder_exists": os.path.exists(UPLOAD_FOLDER),
        "writable": os.access(UPLOAD_FOLDER, os.W_OK),
        "files": os.listdir(UPLOAD_FOLDER) if os.path.exists(UPLOAD_FOLDER) else []
    })

if __name__ == '__main__':
    print(f"\n🌐 Server starting on: http://localhost:5000")
    print(f"📤 Upload endpoint: http://localhost:5000/upload")
    print(f"📋 Test page: http://localhost:5000/test")
    print("=" * 60)
    print("🚀 Ready! Start the Mario game in another terminal")
    print("=" * 60)
    
    app.run(host='0.0.0.0', port=5000, debug=True, use_reloader=False)